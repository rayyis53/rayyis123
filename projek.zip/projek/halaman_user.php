<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Pendaftaran Futsal</title>
</head>
<body>
    <nav class="navbar">
        <h1 class="logo">Pendaftaran Futsal</h1>
        <ul class="menu">
            <li><a href="login.php">Login Admin</a></li>
            <li><a href="halaman_user.php">Home</a></li>
            <li><a href="user_pertandingan.php">Pertandingan</a></li>
            <li><a href="user_turnamen.php">Jadwal</a></li>
            <li><a href="user_kontak.php">Kontak</a></li>
        </ul>
    </nav>
    <div class="content">
        <!-- Isi konten situs web Anda -->
    </div>
</body>
</html>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
</head>
<style>
    /* Reset default margin and padding */
body, h1, h2, p {
    margin: 0;
    padding: 0;
}

/* Set background color and text color */
body {
    background-color: #fff;
    color: #333;
    font-family: Arial, sans-serif;
}

/* Style the header */
.hero {
    background-image: url('background-image.jpg'); /* Ganti dengan URL gambar latar belakang yang Anda inginkan */
    background-size: cover;
    background-position: center;
    text-align: center;
    padding: 100px 0;
}

.hero h1 {
    font-size: 36px;
    color: #000000;
}

/* Style the features section */
.features {
    display: flex;
    justify-content: space-around;
    align-items: center;
    padding: 40px 0;
}

.feature {
    text-align: center;
}

.feature h2 {
    font-size: 24px;
    margin-bottom: 10px;
    color: #333;
}

.feature p {
    font-size: 16px;
    color: #666;
}

/* Style the footer */
.footer {
    text-align: center;
    padding: 70px 0;
    background-color: #333;
    color: #fff;
}

/* Add animation */
.feature {
    transform: translateY(0);
    opacity: 0;
    transition: transform 0.5s ease, opacity 0.5s ease;
}

.features:hover .feature {
    transform: translateY(-10px);
    opacity: 1;
}
</style>
<body>
    <header class="hero">
        <h1>Selamat Datang di Pendaftaran Futsal</h1>
        <p>Daftar sekarang untuk bergabung dalam turnamen futsal kami.</p>
        <a href="user_pendaftaran.php" class="cta-button">Daftar Sekarang</a>
    </header>

    <section class="features">
        <div class="feature">
            <h2>Turnamen Berkualitas</h2>
            <p>Nikmati pengalaman bermain futsal yang berkualitas dengan pemain-pemain terbaik.</p>
        </div>
        <div class="feature">
            <h2>Infrastruktur Modern</h2>
            <p>Kami memiliki lapangan futsal yang modern dan fasilitas yang lengkap.</p>
        </div>
        <div class="feature">
            <h2>Persaingan Sengit</h2>
            <p>Buktikan kemampuan Anda dalam persaingan sengit dengan tim-tim terbaik.</p>
        </div>
    </section>

    <!-- Konten lainnya untuk beranda Anda -->

    <footer class="footer">
        <p>&copy; 2023 Pendaftaran Futsal. Hak cipta dilindungi.</p>
    </footer>
</body>
</html>