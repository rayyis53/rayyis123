<?php
include 'koneksi.php';

$id = $_GET['id'];
$result = mysqli_query($koneksi, "SELECT id_pertandingan FROM pertandingan WHERE id_pertandingan='$id'");
$row = mysqli_fetch_assoc($result);
$namaturnamen = $row['id_pertandingan'];

if (mysqli_query($koneksi, "DELETE FROM pertandingan WHERE id_pertandingan='$id'")) {
    echo "<script>alert('Data $namaturnamen berhasil dihapus.'); window.location.href = 'pertandingan.php';</script>";
} else {
    echo "<script>alert('Error: " . mysqli_error($koneksi) . "'); window.location.href = 'pertandingan.php';</script>";
}

mysqli_close($koneksi);
?>