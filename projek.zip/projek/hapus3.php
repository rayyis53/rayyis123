<?php
include 'koneksi.php';

$id = $_GET['id'];
$result = mysqli_query($koneksi, "SELECT id FROM pendaftaran WHERE id='$id'");
$row = mysqli_fetch_assoc($result);
$namaturnamen = $row['id'];

if (mysqli_query($koneksi, "DELETE FROM pendaftaran WHERE id='$id'")) {
    echo "<script>alert('Data $namaturnamen berhasil dihapus.'); window.location.href = 'user_pendaftaran.php';</script>";
} else {
    echo "<script>alert('Error: " . mysqli_error($koneksi) . "'); window.location.href = 'user_pendaftaran.php';</script>";
}

mysqli_close($koneksi);
?>