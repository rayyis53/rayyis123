<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Jadwal</title>
</head>
<body>
    <nav class="navbar">
        <h1 class="logo">Pendaftaran Futsal</h1>
        <ul class="menu">
            <li><a href="login.php">Login Admin</a></li>
            <li><a href="halaman_user.php">Home</a></li>
            <li><a href="user_pertandingan.php">Pertandingan</a></li>
            <li><a href="user_turnamen.php">Jadwal</a></li>
            <li><a href="user_kontak.php">Kontak</a></li>

        </ul>
    </nav>
    <div class="content">
        <!-- Isi konten situs web Anda -->
    </div>
</body>
</html>
  
  <style>
    /* Add some basic styling to the table */
    body {
      font-family: Arial, sans-serif;
      background-color: #f0f0f0;
      text-align: center;
      margin: 0;
      padding: 0;
    }

    h2 {
      background-color: #333;
      color: #fff;
      padding: 20px 0;
      margin: 0;
    }

    table {
      border-collapse: collapse;
      width: 100%;
      border: 1px solid #ccc;
      background-color: #fff;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    th, td {
      border: 1px solid #ccc;
      padding: 15px;
      text-align: left;
    }

    th {
      background-color: #808080;
      color: #fff;
    }

    tr:nth-child(even) {
      background-color: #d3d3d3;
    }

    tr:hover {
      background-color: #ddd;
      transform: scale(1.02); /* Menambahkan efek animasi scaling saat dihover */
    }

    a.button {
      display: inline-block;
      background-color: #333;
      color: #fff;
      padding: 5px 30px;
      text-decoration: none;
      margin: 5px;
      border-radius: 5px;
      transition: background-color 0.3s ease; /* Efek transisi warna latar belakang */
    }

    a.button:hover {
      background-color: #555; /* Warna latar belakang saat tombol dihover */
    }
  </style>
</head>
<title>Jadwal</title>
<body>
  <h2>DATA TURNAMEN</h2>
 
  <table border="1">
    <tr>
      <th>NO</th>
      <th>ID TURNAMEN</th>
      <th>NAMA_TURNAMEN</th>
      <th>TANGGAL MULAI</th>
      <th>TANGGAL SELESAI</th>
    </tr>
    <?php 
      include 'koneksi.php';
      $no = 1;
      $data = mysqli_query($koneksi,"select * from turnamen");
      while($d = mysqli_fetch_array($data)){
    ?>
    <tr>
      <td><?php echo $no++; ?></td>
      <td><?php echo $d['id_turnamen']; ?></td>
      <td><?php echo $d['nama_turnamen']; ?></td>
      <td><?php echo $d['tanggal_mulai']; ?></td>
      <td><?php echo $d['tanggal_selesai']; ?></td>
      <td>


      </td>
    </tr>
    <?php 
      }
    ?>
  </table>
</body>
</html>
