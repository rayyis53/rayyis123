<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Pertandingan</title>
</head>
<body>
    <nav class="navbar">
        <h1 class="logo">Pendaftaran Futsal</h1>
        <ul class="menu">
            <li><a href="login.php">Login Admin</a></li>
            <li><a href="halaman_admin.php">Home</a></li>
            <li><a href="pertandingan.php">Pertandingan</a></li>
            <li><a href="turnamen.php">Jadwal</a></li>
            <li><a href="pendaftaran.php">Data Pendaftaran</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </nav>
    <div class="content">
        <!-- Isi konten situs web Anda -->
    </div>
</body>
</html>

<style>
    /* Add some basic styling to the table */
    body {
      font-family: Arial, sans-serif;
      background-color: #f0f0f0;
      text-align: center;
      margin: 0;
      padding: 0;
    }

    h2 {
      background-color: #333;
      color: #fff;
      padding: 20px 0;
      margin: 0;
    }

    table {
      border-collapse: collapse;
      width: 100%;
      border: 1px solid #ccc;
      background-color: #fff;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    th, td {
      border: 1px solid #ccc;
      padding: 15px;
      text-align: left;
    }

    th {
      background-color: #808080;
      color: #fff;
    }

    tr:nth-child(even) {
      background-color: #d3d3d3;
    }

    tr:hover {
      background-color: #ddd;
      transform: scale(1.02); /* Menambahkan efek animasi scaling saat dihover */
    }

    a.button {
      display: inline-block;
      background-color: #333;
      color: #fff;
      padding: 5px 30px;
      text-decoration: none;
      margin: 5px;
      border-radius: 5px;
      transition: background-color 0.3s ease; /* Efek transisi warna latar belakang */
    }

    a.button:hover {
      background-color: #555; /* Warna latar belakang saat tombol dihover */
    }
  </style>
</head>
<title>Pertandingan</title>
<body>
  <h2>DATA PERTANDINGAN</h2>
  <a class="button" href="tambah2.php">TAMBAH PERTANDINGAN</a>
  <table border="1">
    <tr>
      <th>NO</th>
      <th>ID PERTANDINGAN</th>
      <th>ID TURNAMEN</th>
      <th>TIM TUAN RUMAH</th>
      <th>TIM TAMU</th>
      <th>SKOR TUAN RUMAH</th>
      <th>SKOR TAMU</th>
      <th>TANGGAL PERTANDINGAN</th>
      <th>OPSI</th>
    </tr>
    <?php 
      include 'koneksi.php';
      $no = 1;
      $data = mysqli_query($koneksi,"select * from pertandingan");
      while($d = mysqli_fetch_array($data)){
    ?>
    <tr>
      <td><?php echo $no++; ?></td>
      <td><?php echo $d['id_pertandingan']; ?></td>
      <td><?php echo $d['id_turnamen']; ?></td>
      <td><?php echo $d['tim_tuan_rumah']; ?></td>
      <td><?php echo $d['tim_tamu']; ?></td>
      <td><?php echo $d['skor_tuan_rumah']; ?></td>
      <td><?php echo $d['skor_tamu']; ?></td>
      <td><?php echo $d['tanggal_pertandingan']; ?></td>
      <td>
        <a class="button" href="edit2.php?id=<?php echo $d['id_turnamen']; ?>">EDIT</a>
        <a class="button" href="hapus2.php?id=<?php echo $d['id_turnamen']; ?>">HAPUS</a>
      </td>
    </tr>
    <?php 
      }
    ?>
  </table>
</body>
</html>
