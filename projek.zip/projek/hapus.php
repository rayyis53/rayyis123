<?php
include 'koneksi.php';

$id = $_GET['id'];
$result = mysqli_query($koneksi, "SELECT id_turnamen FROM turnamen WHERE id_turnamen='$id'");
$row = mysqli_fetch_assoc($result);
$namaturnamen = $row['id_turnamen'];

if (mysqli_query($koneksi, "DELETE FROM turnamen WHERE id_turnamen='$id'")) {
    echo "<script>alert('Data $namaturnamen berhasil dihapus.'); window.location.href = 'turnamen.php';</script>";
} else {
    echo "<script>alert('Error: " . mysqli_error($koneksi) . "'); window.location.href = 'turnamen.php';</script>";
}

mysqli_close($koneksi);
?>